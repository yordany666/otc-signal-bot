# quotex.py
